var random = Math.floor(Math.random() * 9);

document.getElementById(random + "").src="reddot.jpeg";

var pic = 0;

function coin(){
return Math.floor(Math.random() * 2);
}


if(random == 0){

p1 = coin();

pic = p1 ? "1" : "3";

}

if(random == 1){

var num = ['0','2','4'];

pic = num[Math.floor(Math.random() * num.length)];

}

if(random == 2){

p2 = coin();

pic = p2 ? "1" : "5";

}

if(random == 3){

var num = ['0','4','6'];

pic = num[Math.floor(Math.random() * num.length)];

}

if(random == 4){

var num = ['1','3','7','5'];

pic = num[Math.floor(Math.random() * num.length)];

}

if(random == 5){

var num = ['2','4','8'];

pic = num[Math.floor(Math.random() * num.length)];

}

if(random == 6){

p3 = coin();

pic = p3 ? "3" : "7";

}

if(random == 7){

var num = ['6','4','8'];

pic = num[Math.floor(Math.random() * num.length)];

}

if(random == 8){

p4 = coin();

pic = p4 ? "7" : "5";

}

document.getElementById(pic + "").src="reddot.jpeg";


for(i=0; i < 3; i++){
	
if(pic == 0){

p1 = coin();

pic1 = p1 ? "1" : "3";

}

if(pic == 1){

var num = ['0','2','4'];

pic1 = num[Math.floor(Math.random() * num.length)];

}

if(pic == 2){

p2 = coin();

pic1 = p2 ? "1" : "5";

}

if(pic == 3){

var num = ['0','4','6'];

pic1 = num[Math.floor(Math.random() * num.length)];

}

if(pic == 4){

var num = ['1','3','7','5'];

pic1 = num[Math.floor(Math.random() * num.length)];

}

if(pic == 5){

var num = ['2','4','8'];

pic1 = num[Math.floor(Math.random() * num.length)];

}

if(pic == 6){

p3 = coin();

pic1 = p3 ? "3" : "7";

}

if(pic == 7){

var num = ['6','4','8'];

pic1 = num[Math.floor(Math.random() * num.length)];

}

if(pic == 8){

p4 = coin();

pic1 = p4 ? "7" : "5";

}

document.getElementById(pic1 + "").src="reddot.jpeg";
	
	
	
}



